<?php
    require_once('connect.php');

    session_start();
    $name = $_GET['name'];
    $phno = $_SESSION['phno'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Menu - Voice-Based Banking</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="dashboard1.css">
</head>
<body>

  <nav>
    <div class="logo">Smart Bank</div>
    <div>
      <a href="/">Home</a>
      <a href="../logout.php">Logout</a>
    </div>
  </nav>

  <div class="container">
    <h1>Welcome, <?php echo $name ?></h1>
    <p>Select an action below:</p>

    <button class="action-button fade">Hard Copy to Digital</button>
    <a href="./services/dashboard.php"><button class="action-button rotate">Digital Form</button></a>
    <button class="action-button fade" onclick="location.href='/view-history'">Debit</button>
    <button class="action-button rotate" onclick="location.href='/change-password'">Credit</button>
  </div>

</body>
</html>
