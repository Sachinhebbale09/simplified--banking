<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>AI-Powered Banking</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
      overflow: hidden;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    /* Background Video Styling */
    #bg-video {
      position: fixed;
      right: 0;
      bottom: 0;
      min-width: 100%;
      min-height: 100%;
      object-fit: cover;
      z-index: -1;
    }

    /* Centered Welcome Text */
    .centered-text {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
      animation: zoomInFade 2.5s ease forwards;
    }
    .centered-text h1 {
      font-size: 2.2rem;
      background: linear-gradient(90deg, #00ffff, #ff00ff, #00ffff);
      -webkit-background-clip: text;
      background-clip: text;
      -webkit-text-fill-color: transparent;
      background-size: 300% 300%;
      animation: shimmer 4s ease infinite, pulse 4s infinite alternate;
    }

    .btn {
      margin-top: 1.5rem;
      padding: 10px 22px;
      font-size: 1rem;
      background: #00ffff;
      border: none;
      color: #000;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: 600;
      box-shadow: 0 0 10px #00ffff;
    }

    .btn:hover {
      background: #ff00ff;
      color: white;
      box-shadow: 0 0 15px #ff00ff;
    }

    /* Animations */
    @keyframes shimmer {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    @keyframes pulse {
      0% { transform: scale(1); }
      100% { transform: scale(1.05); }
    }

    @keyframes zoomInFade {
      0% {
        opacity: 0;
        transform: scale(0.9) translate(-50%, -50%);
      }
      100% {
        opacity: 1;
        transform: scale(1) translate(-50%, -50%);
      }
    }

    @media (max-width: 600px) {
      .centered-text h1 {
        font-size: 1.5rem;
      }
      .btn {
        font-size: 0.9rem;
        padding: 8px 18px;
      }
    }
  </style>
</head>
<body>
  <!-- Background Video -->
  <video autoplay muted loop id="bg-video">
  <source src="../static/video/aibanking.mp4" type="video/mp4">
  Your browser does not support the video tag.
</video>


  <!-- Welcome Message -->
  <div class="centered-text">
    <h1>Welcome to AI-Powered Banking System</h1>
    <a href="./voice_login.php" class="btn">Get Started</a>

  </div>
</body>
</html>
