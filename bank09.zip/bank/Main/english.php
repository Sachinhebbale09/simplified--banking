<?php
    require_once('connect.php');
    $message="";
    $message1="";

    if(isset($_POST['submit']))
    {
        $pass = $_POST['pwd'];
       
        if(!(empty($pass)))
        {
            $phno_err = " SELECT * from users where pass = '$pass'";
            $ph = mysqli_query($connect, $phno_err);
            $phno_count = mysqli_num_rows($ph);

            $sql = "SELECT name from users WHERE pass = '$pass'";
            $result = mysqli_query($connect, $sql);
            $row = mysqli_fetch_assoc($result);
            $name = $row['name'];

            if($phno_count > 0)
            {
                session_start();
                $_SESSION["pass"] = $pass;
                
                header("location: ../Main/dashboard.php?name=$name");
                
            }
            else
            {
                $message= "Please Check your Password ";
                
            }
        } 
    }

?> 

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <link rel="stylesheet" href="english_css.css">
    <!-- <link rel="stylesheet" href="style1.css"> -->
    <link href="./admin_register.php">
</head>
<body>

    <div class="container" id="container">
        <div class="form-container sign-in-container">
            <form action="./english.php" method="POST">
                <h1>Sign in</h1>
                <div class="infield">
                    <input type="password" placeholder="Password" name="pwd" required/>
                    <label></label>
                </div>
                <div class='message' style=color:#ff2770><?php echo"$message";?></div>
                <button type="submit" name="submit">Sign In</button>
                
                <button id="btn"><a href="./admin_register.php">Sign Up</a></button>
            </form>
        </div>
        <div class="overlay-container" id="overlayCon">
            <div class="overlay">
                <div class="overlay-panel overlay-right">
                    <h1>Hello, Friend!</h1>
                    <p>Enter your personal details and start journey with us</p>
                    <button>Sign Up</button>   
                </div>
            </div>
            <a href="./admin_register.php"><button id="overlayBtn"></button></a>
        </div>
    </div>
    <script src="script.js"></script>

</body>
</html>