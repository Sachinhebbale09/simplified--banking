<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <h1>Welcome to Voice Banking</h1>
    <button onclick="location.href='/deposit'">Deposit</button><br><br>
    <button onclick="location.href='/withdraw'">Withdrawal</button><br><br>
    <button onclick="location.href='/kyc'">KYC</button><br><br>
    <button onclick="window.history.back()">Back</button>

    <!-- Voice Assistant Output -->
    <script>
      window.onload = function() {
        const content = Array.from(document.body.querySelectorAll('h1, label, button'))
          .map(el => el.innerText)
          .filter(Boolean)
          .join('. ');

        const msg = new SpeechSynthesisUtterance(content + ". You can say Deposit, Withdrawal, KYC or Back.");
        msg.lang = 'en-US';
        msg.rate = 1;
        speechSynthesis.speak(msg);

        // Start listening after speaking
        msg.onend = function () {
          startListening();
        };
      };

      function startListening() {
        if (!('webkitSpeechRecognition' in window)) {
          alert("Sorry, your browser does not support Speech Recognition.");
          return;
        }

        const recognition = new webkitSpeechRecognition();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.start();

        recognition.onresult = function(event) {
          const command = event.results[0][0].transcript.toLowerCase();
          console.log("Heard:", command);

          if (command.includes("deposit")) {
            window.location.href = "/deposit";
          } else if (command.includes("withdraw")) {
            window.location.href = "/withdraw";
          } else if (command.includes("kyc")) {
            window.location.href = "/kyc";
          } else if (command.includes("back")) {
            window.history.back();
          } else {
            const retry = new SpeechSynthesisUtterance("Command not recognized. Please say Deposit, Withdrawal, KYC, or Back.");
            retry.lang = 'en-US';
            retry.onend = () => recognition.start();  // Restart listening
            speechSynthesis.speak(retry);
          }
        };

        recognition.onerror = function(event) {
          console.error("Speech recognition error", event.error);
          recognition.start(); // Retry on error
        };
      }
    </script>
</body>
</html>
