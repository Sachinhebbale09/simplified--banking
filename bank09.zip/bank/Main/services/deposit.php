<!DOCTYPE html>
<html>
<head><title>Deposit Form</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Deposit Form</h1>
    <form>
        <label>Name:</label><br>
        <input type="text" value="{{ user[0] }}" readonly><br><br>

        <label>Account Details:</label><br>
        <input type="text" value="{{ user[1] }}" readonly><br><br>

        <label>Amount:</label><br>
      <input type="text" id="amount" name="amount"><br><br>
    </form>
    <button onclick="window.print()">Print</button><br><br>
    <button onclick="location.href='/'">Back</button>
    <!-- Voice Assistant + Voice Input Script -->
    <script>
  window.onload = function () {
    const content = Array.from(document.body.querySelectorAll('h1, label, button, input[readonly]'))
      .map(el => el.innerText || el.value)
      .filter(Boolean)
      .join('. ');

    const msg = new SpeechSynthesisUtterance(content + ". Please say the deposit amount.");
    msg.lang = 'en-US';
    msg.rate = 1;
    speechSynthesis.speak(msg);

    msg.onend = () => listenForAmount();
  };

  function listenForAmount() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.start();

    recognition.onresult = function (event) {
      let speech = event.results[0][0].transcript.toLowerCase().trim();
      console.log("Heard:", speech);

      let digitsOnly = speech.match(/\d+/g);
      if (!digitsOnly) {
        const words = speech.split(/\s+/);
        const numberWords = {
          "one": "1", "two": "2", "three": "3", "four": "4", "five": "5",
          "six": "6", "seven": "7", "eight": "8", "nine": "9", "ten": "10",
          "zero": "0", "hundred": "00", "thousand": "000"
        };
        let numStr = '';
        for (let word of words) {
          if (numberWords[word]) {
            numStr += numberWords[word];
          }
        }
        if (numStr.length > 0) digitsOnly = [numStr];
      }

      if (digitsOnly && digitsOnly.length > 0) {
        const amount = digitsOnly[0];
        document.getElementById("amount").value = amount;
        const confirmMsg = new SpeechSynthesisUtterance("Amount " + amount + " entered. Is this correct? Say yes or no.");
        confirmMsg.onend = () => listenForConfirmation(amount);
        speechSynthesis.speak(confirmMsg);
      } else {
        const retry = new SpeechSynthesisUtterance("No number detected. Please try again.");
        retry.onend = () => listenForAmount();
        speechSynthesis.speak(retry);
      }
    };
  }

  function listenForConfirmation(amount) {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function (event) {
      const response = event.results[0][0].transcript.toLowerCase().trim();
      if (response.includes("yes")) {
        const askPrint = new SpeechSynthesisUtterance("Do you want to print the form? Say yes or no.");
        askPrint.onend = () => listenForPrint();
        speechSynthesis.speak(askPrint);
      } else {
        const tryAgain = new SpeechSynthesisUtterance("Okay, please say the amount again.");
        tryAgain.onend = () => listenForAmount();
        speechSynthesis.speak(tryAgain);
      }
    };
  }

  function listenForPrint() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function (event) {
      const response = event.results[0][0].transcript.toLowerCase().trim();
      if (response.includes("yes")) {
        window.print();
      } else {
        const askBack = new SpeechSynthesisUtterance("Say 'Back' to return to home page.");
        askBack.onend = () => listenForBack();
        speechSynthesis.speak(askBack);
      }
    };
  }

  function listenForBack() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function (event) {
      const command = event.results[0][0].transcript.toLowerCase().trim();
      if (command.includes("back")) {
        window.location.href = "{{ url_for('home') }}";
      } else {
        const retry = new SpeechSynthesisUtterance("Please say 'Back' to return to the home page.");
        retry.onend = () => listenForBack();
        speechSynthesis.speak(retry);
      }
    };
  }
</script>

</body>
</html>
