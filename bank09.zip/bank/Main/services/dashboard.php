<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Menu - Voice-Based Banking</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../dashboard1.css">
</head>
<body>

  <nav>
    <div class="logo">Smart Bank</div>
    <div>
      <a href="/">Home</a>
      <a href="../logout.php">Logout</a>
    </div>
  </nav>

  <div class="container">
    <h1>Welcome</h1>
    <p>Select an action below:</p>

    <a href="deposit.php"><button class="action-button fade">Deposit Form</button></a>
    <a href="withdrawl.php"><button class="action-button rotate">Withdrawal Form</button></a>
    <a href="kyc.php"><button class="action-button fade">KYC</button></a>
  </div>

</body>
</html>
