<!DOCTYPE html>
<html>
<head><title>KYC Form</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>KYC Form</h1>
    <form>
        <label>Name:</label><br>
        <input type="text" value="{{ user[0] }}" readonly><br><br>

        <label>Address:</label><br>
        <textarea readonly>{{ user[3] }}</textarea><br><br>

        <label>Bank Details:</label><br>
        <input type="text" value="{{ user[2] }}" readonly><br><br>

        <label>Aadhaar Number:</label><br>
        <input type="text" id="aadhaar" name="aadhaar" required><br><br>

        <label>PAN Card Number:</label><br>
        <input type="text" id="pancard" name="pancard" required><br><br>

        <label>Mobile Number:</label><br>
        <input type="text" value="{{ user[4] }}" readonly><br><br>
    </form>
    <button onclick="window.print()">Print</button><br><br>
    <button onclick="location.href='/'">Back</button>
    <script>
  window.onload = function () {
    const content = Array.from(document.body.querySelectorAll('h1, label, button, input[readonly]'))
      .map(el => el.innerText || el.value)
      .filter(Boolean)
      .join('. ');

    const msg = new SpeechSynthesisUtterance(content + ". Please say your 12-digit Aadhaar number.");
    msg.lang = 'en-US';
    msg.rate = 1;
    msg.onend = () => setTimeout(() => listenForAadhaar(), 500);
    speechSynthesis.speak(msg);
  };

  function listenForAadhaar() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function (event) {
      const result = event.results[0][0].transcript.replace(/\D/g, ''); // digits only
      if (result.length === 12) {
        document.getElementById("aadhaar").value = result;
        const msg = new SpeechSynthesisUtterance("Aadhaar number " + result + " entered. Please say your 10-character PAN card number.");
        msg.onend = () => listenForPan();
        speechSynthesis.speak(msg);
      } else {
        const retry = new SpeechSynthesisUtterance("Invalid Aadhaar. Please say your 12-digit Aadhaar number again.");
        retry.onend = () => listenForAadhaar();
        speechSynthesis.speak(retry);
      }
    };
  }

  function listenForPan() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function (event) {
      let result = event.results[0][0].transcript.replace(/\s/g, '').toUpperCase();
      result = result.replace(/[^A-Z0-9]/g, '');

      if (result.length === 10) {
        document.getElementById("pancard").value = result;
        const confirmMsg = new SpeechSynthesisUtterance("PAN number " + result + " entered. Are these details correct? Say yes or no.");
        confirmMsg.onend = () => listenForConfirmation();
        speechSynthesis.speak(confirmMsg);
      } else {
        const retry = new SpeechSynthesisUtterance("Invalid PAN. Please say your 10-character PAN number again.");
        retry.onend = () => listenForPan();
        speechSynthesis.speak(retry);
      }
    };
  }

  function listenForConfirmation() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function (event) {
      const response = event.results[0][0].transcript.toLowerCase();
      if (response.includes("yes")) {
        const printMsg = new SpeechSynthesisUtterance("Do you want to print the form? Say yes or no.");
        printMsg.onend = () => listenForPrint();
        speechSynthesis.speak(printMsg);
      } else {
        const retry = new SpeechSynthesisUtterance("Okay. Let's fill in Aadhaar again.");
        retry.onend = () => listenForAadhaar();
        speechSynthesis.speak(retry);
      }
    };
  }

  function listenForPrint() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function (event) {
      const response = event.results[0][0].transcript.toLowerCase();
      if (response.includes("yes")) {
        window.print();
      } else {
        const backMsg = new SpeechSynthesisUtterance("Say 'Back' to return to the home page.");
        backMsg.onend = () => listenForBack();
        speechSynthesis.speak(backMsg);
      }
    };
  }

  function listenForBack() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function (event) {
      const cmd = event.results[0][0].transcript.toLowerCase();
      if (cmd.includes("back")) {
        window.location.href = "{{ url_for('home') }}";
      } else {
        const retry = new SpeechSynthesisUtterance("Please say 'Back' to go home.");
        retry.onend = () => listenForBack();
        speechSynthesis.speak(retry);
      }
    };
  }
</script>


</body>
</html>
