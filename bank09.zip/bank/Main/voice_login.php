<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Voice-Based Multilingual Banking Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    /* Base reset */
*, *::before, *::after {
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  margin: 0;
  background: #1e1e2f;
  color: #e0e0e0;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 2rem 1rem;
  min-height: 100vh;
}

h1 {
  font-weight: 700;
  font-size: 2.5rem;
  color: #70c4ff;
  text-shadow: 0 0 10px #70c4ff66;
  margin-bottom: 2rem;
  text-align: center;
}

/* Language buttons container */
#languageButtons {
  display: flex;
  justify-content: center;
  gap: 2rem;               /* increased gap for spacing */
  margin-bottom: 3rem;
  flex-wrap: wrap;         /* wrap on small screens */
}

/* Language buttons styling */
.language-btn {
  background-color: #2a2a40;
  color: #70c4ff;
  border: none;
  border-radius: 14px;     /* slightly rounder */
  padding: 1.2rem 3rem;    /* taller and wider buttons */
  font-weight: 700;
  font-size: 1.4rem;       /* bigger font */
  cursor: pointer;
  box-shadow: 0 0 20px #70c4ff33;
  transition: background-color 0.3s ease, color 0.3s ease, box-shadow 0.3s ease;
  user-select: none;
  min-width: 150px;        /* consistent button width */
  text-align: center;
}

.language-btn:hover,
.language-btn:focus {
  background-color: #70c4ff;
  color: #1e1e2f;
  box-shadow: 0 0 25px #70c4ffcc;
  outline: none;
}

#instruction {
  text-align: center;
  font-size: 1.2rem;
  font-weight: 500;
  margin-bottom: 3rem;
  min-height: 3rem;
  user-select: text;
  color: #a0cfff;
}

#login-area {
  width: 100%;
  max-width: 400px;       /* made wider for inputs */
  margin: 0 auto 3rem;
  display: none;
  text-align: center;
}

#pinInput {
  width: 100%;
  padding: 0.85rem 1rem;
  font-size: 1.15rem;
  border-radius: 12px;
  border: none;
  outline: none;
  background-color: #2a2a40;
  color: #70c4ff;
  box-shadow: inset 0 0 10px #70c4ff66;
  transition: box-shadow 0.3s ease;
  user-select: text;
}

#pinInput::placeholder {
  color: #506a9a;
}

#pinInput:focus {
  box-shadow: 0 0 18px #70c4ffcc;
  background-color: #39558f;
  color: #e0e0e0;
}

/* Login button styling */
button#loginBtn {
  margin-top: 1.8rem;
  width: 100%;
  background-color: #70c4ff;
  color: #1e1e2f;
  font-weight: 700;
  font-size: 1.4rem;
  padding: 1.1rem 0;
  border: none;
  border-radius: 16px;
  cursor: pointer;
  box-shadow: 0 0 22px #70c4ffcc;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  user-select: none;
}

button#loginBtn:hover {
  background-color: #4990ff;
  box-shadow: 0 0 30px #4990ffcc;
}

#message {
  margin-top: 1.5rem;
  font-size: 1.1rem;
  font-weight: 600;
  min-height: 1.5rem;
  user-select: text;
  color: #70c4ff;
  text-align: center;
}

.success {
  color: #28a745;
  text-shadow: 0 0 10px #28a745cc;
}

.error {
  color: #dc3545;
  text-shadow: 0 0 10px #dc3545cc;
}
nav {
  width: 100%;
  max-width: 900px;
  margin: 0 auto 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #70c4ff;
  font-weight: 600;
  font-size: 1.2rem;
}

nav .logo {
  font-size: 1.5rem;
  font-weight: 700;
  color: #70c4ff;
  user-select: none;
}

nav a {
  color: #70c4ff;
  margin-left: 2rem;
  text-decoration: none;
  cursor: pointer;
  transition: color 0.3s ease;
}

nav a:hover {
  color: #4990ff;
}
/* Staff login/register area container */
#staff-login-area {
  max-width: 380px;
  margin: 0 auto;
  background: #2a2a40;
  padding: 1.8rem 2rem;
  border-radius: 16px;
  box-shadow: 0 0 25px #70c4ff44;
  color: #70c4ff;
}

/* Tab switcher buttons container */
.form-tab-switcher {
  display: flex;
  justify-content: center;
  margin-bottom: 1.8rem;
  gap: 1rem;
}

/* Tab buttons */
.form-tab-switcher button {
  flex: 1;
  padding: 0.75rem 0;
  font-size: 1.2rem;
  font-weight: 700;
  border-radius: 14px;
  border: none;
  background-color: #394163;
  color: #70c4ff;
  cursor: pointer;
  box-shadow: 0 0 12px #70c4ff33;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  user-select: none;
}

.form-tab-switcher button:hover {
  background-color: #70c4ff;
  color: #1e1e2f;
  box-shadow: 0 0 18px #70c4ffcc;
}

.form-tab-switcher button.active {
  background-color: #70c4ff;
  color: #1e1e2f;
  box-shadow: 0 0 22px #70c4ffcc;
}

/* Form styles */
#staff-login-form,
#staff-register-form {
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
}

/* Form icon + input container */
.form-icon {
  display: flex;
  align-items: center;
  background-color: #1e1e2f;
  border-radius: 14px;
  padding: 0.75rem 1rem;
  box-shadow: inset 0 0 10px #70c4ff44;
}

.form-icon i {
  margin-right: 0.8rem;
  font-size: 1.3rem;
  color: #70c4ff;
  width: 24px;
  text-align: center;
}

.form-icon input {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  color: #e0e0e0;
  font-size: 1.15rem;
  user-select: text;
}

/* Form buttons */
#staff-login-form button,
#staff-register-form button {
  background-color: #70c4ff;
  color: #1e1e2f;
  font-weight: 700;
  font-size: 1.3rem;
  padding: 1rem 0;
  border-radius: 16px;
  border: none;
  cursor: pointer;
  box-shadow: 0 0 22px #70c4ffcc;
  transition: background-color 0.3s ease, box-shadow 0.3s ease;
  user-select: none;
}

#staff-login-form button:hover,
#staff-register-form button:hover {
  background-color: #4990ff;
  box-shadow: 0 0 30px #4990ffcc;
}
/* Container holding buttons to manage spacing */
.button-group {
  display: flex;
  justify-content: center;
  gap: 1.2rem;  /* space between buttons */
  margin-top: 1.5rem;
}

/* General button style for login and back */
#staff-login-form button,
#staff-register-form button,
#back-to-main-btn {
  flex: 1;  /* make them equal width */
  padding: 1rem 0;
  font-weight: 700;
  font-size: 1.3rem;
  border-radius: 16px;
  border: none;
  cursor: pointer;
  color: #fff;
  user-select: none;

  /* Two-tone gradient: top is #FF7F50 coral, bottom is #FF4500 orange red */
  background: linear-gradient(to bottom, #FF7F50 0%, #FF4500 100%);
  box-shadow: 0 4px 12px #FF7F50AA;
  transition: background 0.3s ease, box-shadow 0.3s ease;
}

#staff-login-form button:hover,
#staff-register-form button:hover,
#back-to-main-btn:hover {
  background: linear-gradient(to bottom, #FF9966 0%, #FF6347 100%);
  box-shadow: 0 6px 18px #FF9966CC;
}
.button-group {
  display: flex;
  gap: 16px;
  justify-content: center;
}

#login-btn, #back-to-main-btn {
  padding: 10px 24px;
  font-size: 16px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  background: linear-gradient(to bottom, #FF7F50, #FF4500);
  color: white;
}
.button-group {
  display: flex;
  gap: 16px;  /* space between buttons */
  justify-content: center; /* center buttons horizontally */
  margin-top: 20px;
}

.button-group button {
  padding: 10px 30px;
  font-size: 16px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  color: white;
  background: linear-gradient(to bottom, #FF7F50 50%, #FF4500 50%);
  transition: background 0.3s ease;
}

.button-group button:hover {
  background: linear-gradient(to bottom, #FF4500 50%, #FF7F50 50%);
}

  </style>
</head>
<body>
  <nav>
    <div class="logo">Smart Bank</div>
    <div>
      <a href="#" onclick="showMainInterface(); return false;">Home</a>
      <a href="../login-register/admin_register.php">Staff Login</a>
    </div>
  </nav>

  <div class="container">
    <h1 id="title">Voice-Based Banking Login</h1>
    <div class="info" id="infoText"></div>

    <div id="languageButtons" style="display: none;">
  <button class="language-btn"><a href="english.php">English</a></button>
  <button class="language-btn" onclick="selectLanguage('hi')">हिन्दी</button>
  <button class="language-btn" onclick="selectLanguage('kn')">ಕನ್ನಡ</button>
</div>

    <div id="login-area" style="display:none;">
      <h3 id="instruction"></h3>
      <button id="login-button" onclick="login()">Login</button>
      <p id="message"></p>
    </div>

    <div id="staff-login-area" style="display:none;">
      <div class="form-tab-switcher">
        <button id="tab-login" class="active" onclick="switchStaffTab('login')">Staff Login</button>
        <button id="tab-register" onclick="switchStaffTab('register')">Staff Register</button>
      </div>

      <!-- Staff Login Form -->
      <!-- <form id="staff-login-form" onsubmit="handleStaffLogin(event)">
        <div class="form-icon">
          <i class="fas fa-user"></i>
          <input type="text" id="staffId" placeholder="Staff ID" required />
        </div>
        <div class="form-icon">
          <i class="fas fa-lock"></i>
          <input type="password" id="staffPassword" placeholder="Password" required />
        </div>
        <div class="button-group">
    <button type="submit">Login</button>
    <button type="button" onclick="showMainInterface()">Back to Main</button>
  </div>
</form> -->

      <!-- Staff Register Form -->
      <!-- <form id="staff-register-form" onsubmit="event.preventDefault(); alert('Staff Registered!'); switchStaffTab('login');" style="display:none;">
        <div class="form-icon">
          <i class="fas fa-user"></i>
          <input type="text" placeholder="Full Name" required />
        </div>
        <div class="form-icon">
          <i class="fas fa-envelope"></i>
          <input type="email" placeholder="Email" required />
        </div>
        <div class="form-icon">
          <i class="fas fa-lock"></i>
          <input type="password" placeholder="Create Password" required />
        </div>
          <div class="button-group">
    <button type="submit">Register</button>
    <button type="button" onclick="switchStaffTab('login')">Back to Login</button>
  </div>
</form> -->
    </div>

    <div id="user-registration-area" style="display: none;">
      <h2>User Registration</h2>
      <form onsubmit="handleUserRegistration(event)">
        <div class="form-icon">
          <i class="fas fa-user"></i>
          <input type="text" id="name" placeholder="Full Name" required />
        </div>
        <div class="form-icon">
          <i class="fas fa-envelope"></i>
          <input type="email" id="email" placeholder="Email" required />
        </div>
        <div class="form-icon">
          <i class="fas fa-phone"></i>
          <input type="tel" id="phone" placeholder="Phone Number" required />
        </div>
        <div class="form-icon">
          <i class="fas fa-map-marker-alt"></i>
          <input type="text" id="address" placeholder="Address" required />
        </div>
        <div class="form-icon">
          <i class="fas fa-lock"></i>
          <input type="password" id="password" placeholder="Create Password" required />
        </div>
        <button type="submit">Register User</button>
        <button type="button" onclick="showStaffLogin()">Back to Staff Login</button>
      </form>
    </div>
  </div>

  <script>
    let selectedLanguage = '';

    function speak(text, lang = 'en-US') {
      if (!window.speechSynthesis) return;
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      window.speechSynthesis.speak(utterance);
    }

    // Multilingual prompt for language selection
    function speakLanguageSelectionPrompt() {
      // English
      speak("Please select your language", 'en-US');
      // Hindi (with slight delay)
      setTimeout(() => speak("कृपया अपनी भाषा चुनें", 'hi-IN'), 2500);
      // Kannada (after Hindi)
      setTimeout(() => speak("ದಯವಿಟ್ಟು ನಿಮ್ಮ ಭಾಷೆಯನ್ನು ಆರಿಸಿ", 'kn-IN'), 5000);
    }

    function showMainInterface() {
      document.getElementById('languageButtons').style.display = 'block';
      document.getElementById('infoText').style.display = 'block';
      document.getElementById('login-area').style.display = 'none';
      document.getElementById('staff-login-area').style.display = 'none';
      document.getElementById('user-registration-area').style.display = 'none';
      document.getElementById('title').textContent = "Voice-Based Banking Login";
      document.getElementById('infoText').innerText = "";
      speakLanguageSelectionPrompt();
    }

    function showStaffLogin() {
      document.getElementById('languageButtons').style.display = 'none';
      document.getElementById('login-area').style.display = 'none';
      document.getElementById('infoText').style.display = 'none';
      document.getElementById('user-registration-area').style.display = 'none';
      document.getElementById('staff-login-area').style.display = 'block';
      document.getElementById('title').textContent = "Staff Login / Register";
      switchStaffTab('login');
    }

    function switchStaffTab(tab) {
      const loginForm = document.getElementById('staff-login-form');
      const registerForm = document.getElementById('staff-register-form');
      const loginTabBtn = document.getElementById('tab-login');
      const registerTabBtn = document.getElementById('tab-register');

      if (tab === 'login') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        loginTabBtn.classList.add('active');
        registerTabBtn.classList.remove('active');
      } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        loginTabBtn.classList.remove('active');
        registerTabBtn.classList.add('active');
      }
    }

    function selectLanguage(lang) {
      selectedLanguage = lang;
      document.getElementById('languageButtons').style.display = 'none';
      document.getElementById('infoText').style.display = 'none';
      document.getElementById('login-area').style.display = 'block';

      let instructionText = '';
      switch (lang) {
        case 'en':
          instructionText = 'Please say your 4-digit PIN to login';
          break;
        case 'hi':
          instructionText = 'कृपया लॉगिन करने के लिए अपना 4-अंकीय पिन कहें';
          break;
        case 'kn':
          instructionText = 'ದಯವಿಟ್ಟು ಲಾಗಿನ್ ಮಾಡಲು ನಿಮ್ಮ 4 ಅಂಕಿಯ ಪಿನ್ ಅನ್ನು ಹೇಳಿ';
          break;
      }
      document.getElementById('instruction').innerText = instructionText;

      // Voice prompt for login instructions
      let langCode = lang === 'en' ? 'en-US' : (lang === 'hi' ? 'hi-IN' : 'kn-IN');
      speak(instructionText, langCode);
    }

    function login() {
      // For demo, just simulate successful login
      document.getElementById('message').innerText = '';
      speak("Processing login...", selectedLanguage === 'en' ? 'en-US' : (selectedLanguage === 'hi' ? 'hi-IN' : 'kn-IN'));

      setTimeout(() => {
        document.getElementById('message').innerText = 'Login successful!';
        document.getElementById('message').className = 'success';
        speak("Login successful", selectedLanguage === 'en' ? 'en-US' : (selectedLanguage === 'hi' ? 'hi-IN' : 'kn-IN'));
      }, 2000);
    }

    function handleStaffLogin(event) {
      event.preventDefault();
      const staffId = document.getElementById('staffId').value.trim();
      const staffPassword = document.getElementById('staffPassword').value.trim();

      if (staffId === '' || staffPassword === '') {
        alert('Please enter Staff ID and Password');
        return;
      }
      alert(`Staff logged in:\nID: ${staffId}`);
      showMainInterface();
    }

    function handleUserRegistration(event) {
      event.preventDefault();
      alert("User Registered Successfully!");
      showStaffLogin();
    }

    // Initialize on page load
    window.onload = () => {
      showMainInterface();
    };
  </script>
</body>
</html>
