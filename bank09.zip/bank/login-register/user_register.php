<?php
    require_once('connect.php');
    $message="";
    $message1="";
    $message2="";
    
    $name =  ( isset($_POST['name']) == TRUE ) ? $_POST['name'] :  '';
    $phno =  ( isset($_POST['phno']) == TRUE ) ? $_POST['phno'] :  '';
    $em =  ( isset($_POST['email']) == TRUE ) ? $_POST['email'] :  '';
    $add =  ( isset($_POST['address']) == TRUE ) ? $_POST['address'] :  '';
    $pass =  ( isset($_POST['pwd']) == TRUE ) ? $_POST['pwd'] :  '';

    if(!(empty($phno)))
    {
        $em_err = " SELECT * from users where phno = '$phno' ";
        $eq = mysqli_query($connect, $em_err);
        $em_count = mysqli_num_rows($eq);
    
        if($em_count > 0)
        {
            $message1="Phone Number already exists";
        }
        else
        {   
            $sql = " INSERT INTO users (name, phno, email, address, pass) values ('$name', '$phno', '$em', '$add', '$pass')";
            $result = mysqli_query($connect, $sql);

            if($result)
            {
                header("location: ../Main/success.php");
            }
        }
    }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Register</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link rel="stylesheet" href="admin_register.css">
     <!-- <link rel="stylesheet" href="style.css"> -->
    <link href="./admin_login.php">
</head>
<body>

    <div class="container1" id="container">
        <div class="form-container1 sign-up-container1">
            <form action="./user_register.php" method="POST">
                <h1>Create Account</h1>
                <div class="infield1">
                    <input type="text" placeholder="Name" name="name" required/>
                    <label></label>
                </div>
                <div class="infield1">
                    <input type="text" placeholder="Phone Number" name="phno" pattern="[0-9]{10}" required/>
                    <label></label>
                </div>
                <div class="infield1">
                    <input type="email" placeholder="Email" name="email" required/>
                    <label></label>
                </div>
                <div class="infield1">
                    <input type="address" placeholder="Address" name="address" required/>
                    <label></label>
                </div>
                <div class="infield1">
                    <input type="password" placeholder="Password" name="pwd" required/>
                    <label></label>
                </div>
                <div class='message' style=color:#ff2770><?php echo"$message1";?></div>
                <button type="submit">Sign Up</button>

                <button id="btn"><a href="./admin_login.php">Sign In</a></button>
            </form>
        </div>
        
    </div>
    <script src="script.js"></script>

</body>
</html>

