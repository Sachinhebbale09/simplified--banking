// Updated JS: main.js for PHP version of voice-based banking system

// Example: Send 4-digit PIN to login_user.php
function loginWithPIN(pin) {
  fetch('login_user.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'pin=' + encodeURIComponent(pin)
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert('Login successful!');
      window.location.href = 'templates/dashboard.html';
    } else {
      alert('Login failed: ' + data.message);
    }
  })
  .catch(error => console.error('Error:', error));
}

// Example: Send registration data to register_user.php
function registerUser(name, pin, language) {
  const formData = new URLSearchParams();
  formData.append('name', name);
  formData.append('pin', pin);
  formData.append('language', language);

  fetch('register_user.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: formData.toString()
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert('User registered successfully!');
    } else {
      alert('Registration failed: ' + data.message);
    }
  })
  .catch(error => console.error('Error:', error));
}
